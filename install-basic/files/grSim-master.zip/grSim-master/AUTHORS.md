# Head Developer
- Ali Koochakzadeh - Amirkabir University of Technology (ali.koochakzade@gmail.com)


# Project Manager
- Mani Monajjemi - Simon Fraser University (https://github.com/mani-monaj)


# Other Contributers
- Christopher Head - University of British Coloumbia (https://github.com/Hawk777)
- Jonathan Fraser - University of British Coloumbia (https://github.com/Binaryblade)
- Verónica Raspeño - University Carlos III of Madrid- (vero.uc3m@gmail.com)
- Alejandro Caparrós - University Carlos III of Madrid - (alexcap.uc3m@gmail.com)
- Jan Segre - RoboIME Team (jan@segre.in)

# Contributers from Parsian Small Size Team from Amirkabir University of Technology
- Sepehr Mohaimanianpour (s.mehdi.mohaimanianpour@gmail.com)
- Arash Behmand (arashbehmand@gmail.com)

