#ifndef CONSTANTS_H
#define CONSTANTS_H


#define ROBOT_COUNT 6

#endif //CONSTANTS_H

